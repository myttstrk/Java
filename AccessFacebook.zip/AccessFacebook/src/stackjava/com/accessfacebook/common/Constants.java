package stackjava.com.accessfacebook.common;

public class Constants {
	public static String FACEBOOK_APP_ID = "359123991240252";
	public static String FACEBOOK_APP_SECRET = "d07e182d8495df6930665d6c39fbe8ac";
	public static String FACEBOOK_REDIRECT_URL = "https://localhost:8443/AccessFacebook/login-facebook";
	public static String FACEBOOK_LINK_GET_TOKEN = "https://graph.facebook.com/oauth/access_token?client_id=%s&client_secret=%s&redirect_uri=%s&code=%s";

}
